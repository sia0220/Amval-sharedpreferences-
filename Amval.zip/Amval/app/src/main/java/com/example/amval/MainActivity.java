package com.example.amval;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.SharedPreferences;
import android.content.Context;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    EditText edtName,edtNum,edtCode;
    Button btnSave,btnRemove,btnClear;
    SharedPreferences shPref;
    public static final String MyPref = "MyPrefers";
    public static final String Name = "nameKey";
    public static final String Num = "numKey";
    public static final String Code = "codeKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


            edtName = (EditText) findViewById(R.id.edt_name);
            edtNum = (EditText) findViewById(R.id.edt_num);
            edtCode = (EditText) findViewById(R.id.edt_code);
            btnSave = (Button) findViewById(R.id.btn_save);
            btnRemove = (Button) findViewById(R.id.btn_remove);
            btnClear = (Button) findViewById(R.id.btn_clear);
            shPref = getSharedPreferences(MyPref, Context.MODE_PRIVATE);

            btnSave.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String n = edtName.getText().toString();
                    String f = edtNum.getText().toString();
                    int a = Integer.parseInt(edtCode.getText().toString());

                    SharedPreferences.Editor sEdit = shPref.edit();
                    sEdit.putString(Name, n);
                    sEdit.putString(Num, f);
                    sEdit.putInt(Code, a);
                    sEdit.apply();

                    Toast.makeText(MainActivity.this, "ذخیره شد", Toast.LENGTH_LONG).show();
                }
            });

            btnRemove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    SharedPreferences.Editor rEdit = shPref.edit();
                    rEdit.remove(Name);
                    rEdit.remove(Num);
                    rEdit.apply();

                    Toast.makeText(MainActivity.this, "حذف شد!", Toast.LENGTH_LONG).show();
                }
            });

            btnClear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor cEdit = shPref.edit();
                    cEdit.clear();
                    cEdit.apply();
                    Toast.makeText(MainActivity.this, "همه اطلاعات حذف شد", Toast.LENGTH_LONG).show();
                }
            });

            if (shPref.contains(Name)) {
                edtName.setText(shPref.getString(Name, null));
            }

            if (shPref.contains(Num)) {
                edtNum.setText(shPref.getString(Num, null));
            }

            if (shPref.contains(Code)) {
                edtCode.setText(String.valueOf(shPref.getInt(Code, 0)));
            }
    }
}